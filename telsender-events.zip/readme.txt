===  TelSender Event ===
Contributors: pechenki
Tags: telegram, Сontact form 7 to telegram, Сontact form 7, wooccommerce to telegram, Wpforms to telegram, wpforms to telegram, events, 
Requires at least: 4.8
Requires PHP: 7.2
Tested up to: 5.8
Stable tag:  0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

 TelSender Event: Add-ons for the plugin [Telsender](https://ru.wordpress.org/plugins/telsender/)

== Features ==

- [x] Login Failed 
- [x] Login success
- [x] Post interception
- [x] Woocommerce Add To Cart
- [ ] Utm


== Installation ==
1- Install TelSender
2- Install TelSender events and activate
3- In the settings, enter the token and id of your chat.
4- selected settings

